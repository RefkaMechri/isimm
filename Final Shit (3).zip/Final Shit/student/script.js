
  var APP_URL_SETTINGS_PORT = "";
  
  window.__HB_ENV__ = {
    AMPLITUDE_API_KEY: "572175c4a8d55397e7751d6633147d00",
    APP_VERSION: "6514a5480b5c82d65d4c991dceece96940e1ea58",
    ASSET_HOST: "https://us.hivebrite.com",
    BING_GEOCODER_API_KEY: "Ajk3qbl-zyeEBGtPsN2hScjjOMVsuwa6kjQGamBXiM2UBRAY8N19KfoGtYoj7W8M",
    CKEDITOR_TIMESTAMP: new Date().getTime(), // Uniq key to invalidate CKEditor cache
    CLUSTER_NAME: "usprod",
    ENVIRONMENT: "" || 'production',
    GOOGLE_RECAPTCHA_V2_SITE_KEY: "6LeDSBkaAAAAAE03INyaOe5PbOpXnCuJ1Vdd7tnO",
    GOOGLEMAPS_API_KEY: "AIzaSyDxYvw7qj3d9T6IIQ5gb7Yi15nWOWSw3Mo",
    HOST: `${"https"}://${"us.hivebrite.com"}${APP_URL_SETTINGS_PORT ? `:${APP_URL_SETTINGS_PORT}` : ''}`,
    LAUNCHDARKLY_CLIENT_SIDE_ID: "5eef60ad572ea10ab14d2609",
    MAPBOX_DEFAULT_LAYER_EN: "cj97fbay116mi2sp6wtjlwhvk",
    MAPBOX_DEFAULT_LAYER_FR: "cj98iip2j2eot2rqg18l3a6u9",
    MAPBOX_ID: "kit-united.cigdtmahj080uvaltlolpka89",
    MAPBOX_KEY: "pk.eyJ1Ijoia2l0LXVuaXRlZCIsImEiOiJjaWdkdG1hd2YwODJzd2VrbjNmdWg2eWVhIn0.TuRpIQECO9U9D2j_syhyeQ",
    MAPBOX_LIGHT_LAYER_EN: "ciu3vxcd800mw2iolkoa3hn0s",
    MAPBOX_LIGHT_LAYER_FR: "cj98iqz782erm2sqgshe023o9",
    PAYPAL_MODE: "production",
    PUBLIC_PATH: "https://static.hivebrite.com/v-6514a5480b5c82d65d4c991dceece96940e1ea58/packs/",
    SATISMETER_PROJECT_KEY: "JHelqsECh6WGDXPcFukFh0FTQpP2NyFD",
    SENTRY_DSN_JAVASCRIPT: "https://6527bb18bf224e8b9b7ffccc1f2ca642@o429123.ingest.sentry.io/5375161",
    STATIC_ASSETS_HOST: "https://static.hivebrite.com",
    STRIPE_PUBLISHABLE_KEY: "pk_live_KdT5tRx1pmCdRSE3b190xoKt00Deb3ZlXR",
    WEBSOCKET_WS_URI: "wss://websocket.us.hivebrite.com",
  }

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({
    'gtm.allowlist': ['google'],
    'gtm.blocklist': ['opt', 'ts', 'gclidw', 'awct', 'sp'],
  });
  
 
  (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer', "GTM-KBSPCK7");
 
  
  var signUpKey = 'sign_up_method';
  
  function getCookieValue(cookieName) {
    var cookies = document.cookie.split(';');
  
    for (var i = 0; i < cookies.length; i++) {
      var cookie = cookies[i].trim();
  
      if (cookie.indexOf(cookieName + '=') === 0) {
        return cookie.substring(cookieName.length + 1);
      }
    }
  
    // If the cookie is not found, return null
    return null;
  }
  
  function clearCookie(cookieName) {
    // Set the expiration date to a past date
    document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  }
  
  function getItem ({ key }) {
    return sessionStorage.getItem(key);
  };
  
  function setItem ({ key, value }) {
    sessionStorage.setItem(key, value);
  };
  
  function getUserData() {
    // Push the user object to the data layer
    window.dataLayer = window.dataLayer || [];
  
    var userId = null;
  
    if (userId) {
      window.dataLayer.push({ event: 'user_info', user: { id: userId }})
  
      if (getItem({ key : signUpKey })) {
        window.dataLayer.push({ event: 'signup', method: getItem({ key : signUpKey })});
  
        setItem({ key: signUpKey, value: null });
      }
    }
  }
  
  // Function to push the event to the data layer
  function pushSearchEvent(queryParams = {}) {
    // Create the event object
    var event = {
      event: 'search',
      page_search: window.location.search,
      search_query: queryParams
    };
  
    // Push the event object to the data layer
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push(event);
  }
  
  function pushLoginMethod() {
    var userId = null;
  
    // Get the value of the login_method cookie
    var loginMethod = getCookieValue('login_method');
  
    if(loginMethod && userId) {
      // Push the login_method to the data layer
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({ event: 'login', method: loginMethod });
  
      getUserData()
    }
  
    clearCookie('login_method');
  }
  
  // Function to push the page_view event to the data layer
  function pushPageViewEvent() {
    if (true) {
      // Retry a bit later if title is not set yet
      if (!document.title) {
        setTimeout(function() {
          pushPageViewEvent();
        }, 500);
  
        return;
      }
    }
  
    // Create the event object
    var event = {
      event: 'page_view',
      page_title: document.title,
      page_location: window.location.href,
      page_path: window.location.pathname,
      page_search: window.location.search
      // You can add any other relevant data to the event object
    };
  
    // Push the event object to the data layer
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push(event);
  }
  
  // eg. ?term= will return false
  // eg. ?termA=&termB=hello return true
  function hasQueryValue(queryParams) {
    let anyParamHasValue = false;
  
    for (const value of queryParams.values()) {
      if (value) {
        anyParamHasValue = true;
        break;
      }
    }
  
    return anyParamHasValue;
  }
  
  // Function to check for URL changes
  function trackUrlChanges() {
    var currentUrl = window.location.href;
    var currentPath = window.location.origin + window.location.pathname;
    var currentSearch = window.location.search;
  
    // Check the URL every second
    setInterval(function() {
      if (currentUrl !== window.location.href) {
        // If the URL has changed, call the function to push the page_view event
        const path = window.location.origin + window.location.pathname;
  
        // Check if path has changed
        if (currentPath !== path) {
          if (true) {
            setTimeout(function() {
              pushPageViewEvent();
            }, 3000)
          } else {
            pushPageViewEvent();
          }
  
          currentPath = path;
        } else if (currentSearch !== window.location.search) {
          const url = window.location.search;
          const queryParams = new URLSearchParams(url);
  
          if (hasQueryValue(queryParams)) {
            const paramsObject = Object.fromEntries(queryParams.entries());
  
            pushSearchEvent(paramsObject);
            currentSearch = window.location.search;
          }
        }
  
        currentUrl = window.location.href
      }
    }, 1000);
  }
  
  // Call the function to track URL changes
  trackUrlChanges();
  
  // Track user, needed only when already connected at the first page session
  getUserData();
  
  // Track login method
  pushLoginMethod();
  
  if (true) {
    // Track the landing page with delay to wait title is fetch
    setTimeout(function() {
      pushPageViewEvent();
    }, 8000);
  } else {
    pushPageViewEvent();
  }

  /**
   * To make sure that our app can make calls to satismeter(...)
   * even before the whole code has been loaded.
   * It makes installation much easier.
   */
  window.satismeter =
    window.satismeter ||
    function () {
      // eslint-disable-next-line prefer-rest-params
      (window.satismeter.q = window.satismeter.q || []).push(arguments);
    };
  
  // To mark when the first part of the code was loaded.
  window.satismeter.l = new Date().getTime();
  
  const script = document.createElement('script');
  const parent = document.getElementsByTagName('script')[0].parentNode;
  
  script.async = true;
  script.src = 'https://app.satismeter.com/js';
  
  parent?.appendChild(script);
